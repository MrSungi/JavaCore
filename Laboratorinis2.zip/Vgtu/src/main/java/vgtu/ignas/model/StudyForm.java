package vgtu.ignas.model;

import java.io.Serializable;

public enum StudyForm implements Serializable {
    INDIRECT, PROLONGED;
}
